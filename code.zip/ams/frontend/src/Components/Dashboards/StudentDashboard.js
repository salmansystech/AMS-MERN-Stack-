import React from 'react';
import Dashboard from '../Dashboard';

const StudentDashboard = () => {
  return <Dashboard role="student" />;
};

export default StudentDashboard;
