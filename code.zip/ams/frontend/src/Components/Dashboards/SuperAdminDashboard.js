import React from 'react';
import Dashboard from '../Dashboard';

const SuperAdminDashboard = () => {
  return <Dashboard role="super-admin" />;
};

export default SuperAdminDashboard;
