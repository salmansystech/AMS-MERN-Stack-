import React from 'react';
import Dashboard from '../Dashboard';

const TeacherDashboard = () => {
  return <Dashboard role="teacher" />;
};

export default TeacherDashboard;
